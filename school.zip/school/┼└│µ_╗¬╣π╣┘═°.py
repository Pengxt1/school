from urllib import request
from bs4 import BeautifulSoup#需安装
from urllib.error import URLError, HTTPError
import re#正则表达式
import random
import urllib
import pymysql#需安装
import os#创建文件夹os.mkdir(fileNamePath)
import shutil#删除有内容文件夹shutil.rmtree("")


#爬取信息alls函数
def alls(url_1,mo,mos):
    xyxw_183imgs={}#存取本地新闻图片路径
    tzggimgs={}    #存取本地通知图片路径
    mthgimgs={}    #存取本地媒体图片路径
    gjzximgs={}    #存取本地咨询图片路径
    pageSize=16#每页的记录数
    url1=url_1#第一页的url
    user_agent_list = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0"
        "Mozilla/5.0(Macintosh;IntelMacOSX10.6;rv:2.0.1)Gecko/20100101Firefox/4.0.1",
        "Mozilla/4.0(compatible;MSIE6.0;WindowsNT5.1)",
        "Opera/9.80(WindowsNT6.1;U;en)Presto/2.8.131Version/11.11",
        "Mozilla/5.0(Macintosh;IntelMacOSX10_7_0)AppleWebKit/535.11(KHTML,likeGecko)Chrome/17.0.963.56Safari/535.11",
        "Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1)",
        "Mozilla/4.0(compatible;MSIE7.0;WindowsNT5.1;Trident/4.0;SE2.XMetaSr1.0;SE2.XMetaSr1.0;.NETCLR2.0.50727;SE2.XMetaSr1.0)"
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1",
        "Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6",
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6",
        "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/19.77.34.5 Safari/537.1",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5",
        "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.36 Safari/536.5",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
        "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.0 Safari/536.3",
        "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24"
    ]
    header={
        "Host":"www.gcu.edu.cn",
        "User-Agent":random.choice(user_agent_list),
        "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language":"zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
        "Connection":"keep-alive",
        "Upgrade-Insecure-Requests":"1",
        "TE":"Trailers"
    }
    #获取该页的每个记录url列表(参数传入本页url)
    def geturl(nowurl):  
        reqs=request.Request(nowurl,headers=header)
        try:
            ffs=request.urlopen(reqs)
            bsObj=BeautifulSoup(ffs,"html.parser")
            itemList=bsObj.findAll("div",{"frag":"窗口14"})
            regex=r'<a href="(.*?)"'
            pa=re.compile(regex)
            urlList=re.findall(pa,str(itemList[0]))
            ffs.close()
            return urlList
        except HTTPError as e:
            print(e)
        except URLError as e:
            print(e)
        else:
            print("OK")
    #获取模块第一页的代码content
    req=request.Request(url1,headers=header)
    ff=request.urlopen(req)
    content=ff.read().decode()
    ff.close()
    pageCount=2
    '''
    #获取模块页数pageCount
    reqs=request.Request(url1,headers=header)
    ffs=request.urlopen(reqs)
    bsObj=BeautifulSoup(ffs,"html.parser")
    pageCountList=bsObj.findAll("em",{"class":"all_pages"})
    pageCount=int(pageCountList[0].text)
    #获取模块总记录allCount
    reqs=request.Request(url1,headers=header)
    ffs=request.urlopen(reqs)
    bsObj=BeautifulSoup(ffs,"html.parser")
    allCountList=bsObj.findAll("em",{"class":"all_count"})
    allCount=int(allCountList[0].text)
    '''
    allCount=32
    #创建模块各页url列表pageurlLists
    pageurlLists=['']*pageCount
    pageurlLists[0]=url1
    v=2
    while v<=pageCount:
        pageurlLists[v-1]="https://www.gcu.edu.cn/"+mo+"/list"+str(v)+".htm"
        v=v+1
    #获取各个记录的url列表everyurlLists
    everyurlLists=[]
    p=0
    while p<pageCount:
        everyurlLists=everyurlLists+geturl(pageurlLists[p])
        p=p+1
        print("第",p,"页的URL爬完了！！")
    print("完成啦")
    print(everyurlLists)
    #获取并下载各个记录的标题和图片及内容
    everytitle=[]#标题列表
    everycontent=[]#内容列表
    L=0
    while L<allCount:
        print("该页地址为:",everyurlLists[L])
        if(everyurlLists[L][0]=='h'):
            reqss=request.Request(everyurlLists[L],headers=header)
        else:
            reqss=request.Request("https://www.gcu.edu.cn"+everyurlLists[L],headers=header)
        try:
            #获取本记录的标题titles
            contentss=request.urlopen(reqss)
            bsObj=BeautifulSoup(contentss,"html.parser")
            titlesList=bsObj.findAll("span",{"class":"Article_Title"})
            titles=titlesList[0].text
            everytitle.append(titles)
            #获取本记录的图片url列表ma
            pdatasList=bsObj.findAll("div",{"class":"Article_Content"})
            pdatas=str(pdatasList[0])#获取正文代码pdatas
            regex=r' src="(.*?)"'
            pa=re.compile(regex)
            ma=re.findall(pa,pdatas)
            print("该页图片：",ma) 
            print("该页标题",titles)
            #获取本记录的内容
            ContentList=bsObj.findAll("div",{"class":"Article_Content"})
            Content=ContentList[0].text
            Content=Content.replace('"',"“")
            Content=Content.replace("'","‘")
            everycontent.append(Content.encode('GBK','ignore').decode('GBk'))
            #下载标题
            print("下载标题：")
            o=open(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+"/标题/{0}.txt".format(str(L+1)),"w",encoding='utf-8')
            o.write(everytitle[L])
            o.close()
            #下载内容
            print("下载内容：")
            o=open(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+"/内容/{0}.txt".format(str(L+1)),"w",encoding='utf-8')
            o.write(everycontent[L])
            o.close()
            #下载图片
            xyxw_183img=""#存取本地新闻图片路径
            tzggimg=""    #存取本地通知图片路径
            mthgimg=""    #存取本地媒体图片路径
            gjzximg=""    #存取本地咨询图片路径
            print("正在下载第",L+1,"个"+mos+"的图片")
            zz=1
            for pi in ma:
                if pi=="":
                    zz=zz-1
                else:
                    try:
                        if pi[0]=='h':
                            preq=request.Request(pi,headers=header)
                        else:
                            preq=request.Request("http://www.gcu.edu.cn"+pi,headers=header)
                        pff=request.urlopen(preq)
                        pi=pff.read()
                        with open(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+"/图片/"+str(L+1)+"_{0}.jpg".format(str(zz)),"wb") as f:
                            f.write(pi)
                            if mo=="xyxw_183":
                                xyxw_183img=xyxw_183img+str(L+1)+"_{0}.jpg".format(str(zz))+";"
                            elif mo=="tzgg":
                                tzggimg=tzggimg+str(L+1)+"_{0}.jpg".format(str(zz))+";"
                            elif mo=="mthg":
                                mthgimg=mthgimg+str(L+1)+"_{0}.jpg".format(str(zz))+";"
                            elif mo=="gjzx":
                                gjzximg=gjzximg+str(L+1)+"_{0}.jpg".format(str(zz))+";"
                        print("该页下载完第",zz,"张图片")
                        pff.close()
                    except HTTPError as e:
                        print(e)
                    except URLError as e:
                        print(e)
                    except UnicodeEncodeError as e:
                        print(e)
                    else:
                        print("OK")
                zz=zz+1
            if mo=="xyxw_183":
                xyxw_183imgs[L+1]=xyxw_183img
            elif mo=="tzgg":
                tzggimgs[L+1]=tzggimg
            elif mo=="mthg":
                mthgimgs[L+1]=mthgimg
            elif mo=="gjzx":
                gjzximgs[L+1]=gjzximg
            L=L+1
        except HTTPError as e:
            print(e)
            if mo=="xyxw_183":
                xyxw_183imgs[L+1]=xyxw_183img
            elif mo=="tzgg":
                tzggimgs[L+1]=tzggimg
            elif mo=="mthg":
                mthgimgs[L+1]=mthgimg
            elif mo=="gjzx":
                gjzximgs[L+1]=gjzximg
            L=L+1
            everytitle.append("")
            everycontent.append("")
        except URLError as e:
            print(e)
        except IndexError as e:
            print(e)
            if mo=="xyxw_183":
                xyxw_183imgs[L+1]=xyxw_183img
            elif mo=="tzgg":
                tzggimgs[L+1]=tzggimg
            elif mo=="mthg":
                mthgimgs[L+1]=mthgimg
            elif mo=="gjzx":
                gjzximgs[L+1]=gjzximg
            L=L+1
            everytitle.append("")
            everycontent.append("")
        else:
            print("OK")
    print("完成爬取")
    if mo=="xyxw_183":
        return xyxw_183imgs
    elif mo=="tzgg":
        return tzggimgs
    elif mo=="mthg":
        return mthgimgs
    elif mo=="gjzx":
        return gjzximgs
#上传到mysql数据库uploads函数
def uploads(mo,mos,xxxximgs):
    l=1
    while l<=32:
        try:
            with open(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+"/标题/{0}.txt".format(str(l)),encoding='UTF-8') as f:
                titles=f.read()
            with open(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+"/内容/{0}.txt".format(str(l)),encoding='UTF-8') as f:
                contents=f.read()
        except FileNotFoundError as e:
            print(e)
            titles=""
            contents=""
        db=pymysql.Connect(host="localhost",port=3306,user="root",passwd="123456",db="big_work",charset="utf8")
        cursor=db.cursor()
        sql='insert into '+mo+'(no,title,content,img) values(%s,"%s","%s","%s")'%(l,titles,contents,xxxximgs[l])
        print(sql)
        cursor.execute(sql)
        db.commit()
        db.close()
        l=l+1
# 初始化数据库表函数
def inittable(mo):
    db = pymysql.Connect(host="localhost", port=3306, user="root", passwd="123456", db="big_work", charset="utf8")
    cursor = db.cursor()
    sql = "drop table if exists "+mo
    print(sql)
    cursor.execute(sql)
    db.commit()
    db.close()
    db = pymysql.Connect(host="localhost", port=3306, user="root", passwd="123456", db="big_work", charset="utf8")
    cursor = db.cursor()
    sql = "create table "+mo+" (no int(11) AUTO_INCREMENT NOT NULL UNIQUE,title varchar(2000),content longtext,img varchar(2000) not null default '',PRIMARY KEY(no))"
    print(sql)
    cursor.execute(sql)
    db.commit()
    db.close()
#初始化文件夹函数
def initfile(mos):
    shutil.rmtree(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+"/标题")
    shutil.rmtree(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+"/内容")
    shutil.rmtree(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+r"/图片")
    os.mkdir(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+"/标题")
    os.mkdir(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+"/内容")
    os.mkdir(r"D:/Software/Study/eclipse/eclipse ide for enterprise java developers/eclipse-workspace/Big_work/WebContent/img/爬虫/"+mos+"/图片")

#初始化文件夹
initfile("新闻")
initfile("通知")
initfile("媒体")
initfile("资讯")
#下载
xyxw_183imgs=alls("https://www.gcu.edu.cn/xyxw_183/list.htm","xyxw_183","新闻")
tzggimgs=alls("https://www.gcu.edu.cn/tzgg/list.htm","tzgg","通知")
mthgimgs=alls("https://www.gcu.edu.cn/mthg/list.htm","mthg","媒体")
gjzximgs=alls("https://www.gcu.edu.cn/gjzx/list.htm","gjzx","资讯")
#初始化数据库表
inittable("xyxw_183")
inittable("tzgg")
inittable("mthg")
inittable("gjzx")

#上传
uploads("xyxw_183","新闻",xyxw_183imgs)
uploads("tzgg","通知",tzggimgs)
uploads("mthg","媒体",mthgimgs)
uploads("gjzx","资讯",gjzximgs)
print("上传完毕！！")

